module.exports = {
    reactStrictMode: true,
    images: {
        domains: ['stackfood.6am.one'],
        staticPageGenerationTimeout: 1500//Domain of image host
    },
}
