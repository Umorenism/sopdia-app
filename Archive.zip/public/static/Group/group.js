import React from "react";
import PropTypes from "prop-types";

const Group = props => {
  return (
    <div>

    </div>
  );
};

Group.propTypes = {
  
};

export default Group;