import React from 'react'
import { CssBaseline, Container } from '@mui/material'

import RefundPolicyPage from './RefundPolicyPage'

const RefundPolicy = () => {
    return (
        <>

        </>
    )
}

export default RefundPolicy
