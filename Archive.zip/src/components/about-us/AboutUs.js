import React from 'react';
import { CssBaseline, Container } from '@mui/material';
import AboutUsPage from "./AboutUsPage";
import {ConfigApi} from "../../hooks/react-query/config/useConfig";



const AboutUs = ({configData}) => {
    return (
        <>
        </>

    );
};

export default AboutUs;
