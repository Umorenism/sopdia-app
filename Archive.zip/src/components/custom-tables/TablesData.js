export const TablesData = [
    {
        id: 1,
        zone_name: 'Dhaka',
        providers: '159',
        services: '6',
        status: 'on',
    },
    {
        id: 2,
        zone_name: 'Dhaka',
        providers: '159',
        services: '6',
        status: 'on',
    },
    {
        id: 3,
        zone_name: 'Dhaka',
        providers: '159',
        services: '6',
        status: 'on',
    },
    {
        id: 4,
        zone_name: 'Dhaka',
        providers: '159',
        services: '6',
        status: 'on',
    },
    {
        id: 5,
        zone_name: 'Dhaka',
        providers: '159',
        services: '6',
        status: 'on',
    },
]
