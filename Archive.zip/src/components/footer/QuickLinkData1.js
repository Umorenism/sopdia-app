export const QuickLinkData1 = [
    {
        name: 'Popular Restaurants',
        value: 'popular',
        link: '/restaurant/popular',
    },
    {
        name: 'Best Reviewed Foods',
        value: 'best-reviewed-foods',
        link: '/products/best-reviewed-foods',
    },
    // {
    //     name: 'Best Selling Restaurants',
    //     value: 'popular',
    //     link: '/products/popular',
    // },
    {
        name: 'New Restaurants',
        value: 'latest',
        link: '/restaurant/latest',
    },
]
