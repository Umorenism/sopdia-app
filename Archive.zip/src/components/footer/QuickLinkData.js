export const QuickLinkData = [
    {
        name: 'Loyalty Points',
        value: 'loyalty',
        link: '/customer/loyality',
    },
    {
        name: 'My Wallet',
        value: 'wallets',
        link: '/customer/wallets',
    },
    {
        name: 'About Us',
        value: 'about Us',
        link: '/about-us',
    },
    {
        name: ' Track Order',
        value: 'track_order',
        link: '/tracking',
    }
]
