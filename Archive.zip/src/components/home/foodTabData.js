export const foodTabData = [
  {
    id: 0,
    category_name: 'Todays Trends',
    value: 'todays-trends',
  },
  {
    id: 1,
    category_name: 'Popular Foods',
    value: 'popular-foods',
  },
  {
    id: 2,
    category_name: 'Best Reviewed',
    value: 'best-reviewed',
  },

]
