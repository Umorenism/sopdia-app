export const mockData = [
    {
        id:0,
        category_name:'Popular',
        products:[
            {
                name:'Coke',
                restaurant_name:'Hungry puppets',
            }
        ]
    },
    {
        id:1,
        category_name:'Burgers',
        products:[
            {
                name:'Spicy',
                restaurant_name:'Hungry puppets',
            }
        ]
    },
    {
        id:2,
        category_name:'Cake',
        products:[
            {
                name:'Cake',
                restaurant_name:'Hungry puppets',
            }
        ]
    },
    {
        id:3,
        category_name:'Pastry',
        products:[
            {
                name:'Pastry',
                restaurant_name:'Hungry puppets',
            }
        ]
    },
    {
        id:4,
        category_name:'Fanta',
        products:[
            {
                name:'Fanta',
                restaurant_name:'Hungry puppets',
            }
        ]
    },
    {
        id:5,
        category_name:'Chess',
        products:[
            {
                name:'Chess',
                restaurant_name:'Hungry puppets',
            }
        ]
    },
    {
        id:6,
        category_name:'Meat',
        products:[
            {
                name:'Meat',
                restaurant_name:'Hungry puppets',
            }
        ]
    },
    {
        id:7,
        category_name:'Banana',
        products:[
            {
                name:'Banana',
                restaurant_name:'Hungry puppets',
            }
        ]
    },

]