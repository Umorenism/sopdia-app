export const mockData = [
    {
        id:0,
        name:'Non-veg',
        value:"non-veg"

    },
    {
        id:1,
        name:'New',
        value:"new"
    },
    {
        id:2,
        name:'From Campaign',
        value:"from_campaign"

    },

]
export const mockData1 = [
    {
        id:0,
        name:'veg',
        value:"veg"

    },
    {
        id:1,
        name:'Top Rated',
        value:"top_rated"
    },
    {
        id:2,
        name:'Popular',
        value:"popular"

    },
    {
        id:3,
        name:'Currently Available',
        value:"currently_available"
    },



]