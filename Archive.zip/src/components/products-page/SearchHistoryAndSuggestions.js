import React from 'react'
import PropTypes from 'prop-types'

const SearchHistoryAndSuggestions = (props) => {
    return <div>SearchHistoryAndSuggestions</div>
}

SearchHistoryAndSuggestions.propTypes = {}

export default SearchHistoryAndSuggestions
