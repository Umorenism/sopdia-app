import React from 'react'
import CheckoutPage from './CheckoutPage'

const CheckOut = () => {
    return (
        <>
            <CheckoutPage/>
        </>
    )
}

export default CheckOut
