import React from 'react'
import { CssBaseline, Container } from '@mui/material'
import ConditionPage from './ConditionPage'

const TermsCondition = () => {
    return (
        <>

        </>
    )
}

export default TermsCondition
