export const networkLimit = 10
