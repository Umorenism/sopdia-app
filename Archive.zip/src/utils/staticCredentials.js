// // Initialize the Firebase app in the service worker by passing the generated config
export const firebaseConfig = {
    apiKey: '',
    authDomain: '',
    projectId: '',
    storageBucket: '',
    messagingSenderId: '',
    appId: '',
    measurementId: '',
}
export const googleClientId = ''
export const facebookAppId = ''

export const appleLoginCredential = {
    appleId: '',
    serviceId: '',
    privateKey: '',
    redirectURI: ``,
}
