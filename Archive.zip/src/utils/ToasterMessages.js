export const loginSuccessFull = 'Logged in successfully'
export const logoutSuccessFull = 'Logged out successfully'
