export const AllRoutes = {
    POPULAR_PRODUCTS: '/products/popular',
    REVIEWED_PRODUCTS: '/products/best-reviewed-foods',
}
